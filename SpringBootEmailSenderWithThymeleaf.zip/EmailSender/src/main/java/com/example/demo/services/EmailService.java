package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.dto.EmailStatus;
import com.example.demo.util.EmailSenderUtil;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
@Component
public class EmailService {
	
	@Autowired
    private EmailSenderUtil emailSender;
 
    @Autowired
    private TemplateEngine templateEngine;
 
    public EmailStatus send(String to, String subject, String templateName, Context context) {
        String body = templateEngine.process(templateName, context);
        return emailSender.sendHtml(to, subject, body);
    }
}
