package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.thymeleaf.context.Context;

import com.example.demo.dto.EmailStatus;
import com.example.demo.dto.MailDto;
import com.example.demo.services.EmailService;
@RestController
@RequestMapping(value = "/api")
public class EmailController {
	@Autowired
	private EmailService emailservice;
	
	
	@PostMapping(value = "email")
	@ResponseStatus(code = HttpStatus.OK)
	public EmailStatus sendEmail(@RequestBody MailDto mail) {
		Context context = new Context();
		context.setVariable("name", mail.getName());
		context.setVariable("id", mail.getId());
		context.setVariable("message", mail.getMessage());
		return emailservice.send(mail.getAddress(), "Introductory Email", "email", context);
	}
}
